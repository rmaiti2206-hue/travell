from pydantic import BaseModel, EmailStr, ConfigDict, Field
from datetime import date, datetime

class DestinationOut(BaseModel):
    id: int
    name: str
    country: str
    category: str
    description: str
    price_per_person: float
    image_url: str
    model_config = ConfigDict(from_attributes=True)

class UserCreate(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    email: str

class UserOut(BaseModel):
    id: int
    name: str
    email: str
    model_config = ConfigDict(from_attributes=True)

class TripCreate(BaseModel):
    user_id: int
    destination_id: int
    start_date: date
    end_date: date
    travellers: int = Field(default=1, ge=1, le=20)
    notes: str = ""

class TripOut(BaseModel):
    id: int
    user_id: int
    destination_id: int
    start_date: date
    end_date: date
    travellers: int
    notes: str
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)

class BookingCreate(BaseModel):
    trip_id: int

class BookingOut(BaseModel):
    id: int
    trip_id: int
    total_amount: float
    status: str
    booked_at: datetime
    model_config = ConfigDict(from_attributes=True)

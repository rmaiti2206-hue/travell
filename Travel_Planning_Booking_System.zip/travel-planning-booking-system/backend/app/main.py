from fastapi import FastAPI, Depends, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import or_
from .database import Base, engine, get_db
from . import models, schemas

Base.metadata.create_all(bind=engine)
app = FastAPI(title="Travel Planning & Booking API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

SEED = [
    ("Bali", "Indonesia", "Beach", "Tropical beaches, emerald rice terraces and unforgettable sunsets.", 680, "https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=1000"),
    ("Swiss Alps", "Switzerland", "Adventure", "Mountain villages, scenic railways and breathtaking alpine trails.", 1450, "https://images.unsplash.com/photo-1531366936337-7c912a4589a7?w=1000"),
    ("Kyoto", "Japan", "Culture", "Traditional streets, peaceful temples and beautiful seasonal gardens.", 920, "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=1000"),
    ("Santorini", "Greece", "Romance", "Whitewashed architecture, blue domes and spectacular sea views.", 1180, "https://images.unsplash.com/photo-1533105079780-92b9be482077?w=1000"),
    ("Rajasthan", "India", "Culture", "Discover royal forts, colourful markets and desert heritage.", 420, "https://images.unsplash.com/photo-1599661046827-dacff0c0f09a?w=1000"),
    ("Maldives", "Maldives", "Beach", "Turquoise lagoons, coral reefs and overwater island escapes.", 1590, "https://images.unsplash.com/photo-1514282401047-d79a71a590e8?w=1000"),
    ("Iceland", "Iceland", "Adventure", "Chase waterfalls, glaciers and the magical northern lights.", 1320, "https://images.unsplash.com/photo-1476610182048-b716b8518aae?w=1000"),
    ("Paris", "France", "City", "Art, architecture, cafe culture and iconic city landmarks.", 990, "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=1000"),
]

@app.on_event("startup")
def seed_destinations():
    db = next(get_db())
    try:
        if db.query(models.Destination).count() == 0:
            for row in SEED:
                db.add(models.Destination(name=row[0], country=row[1], category=row[2],
                    description=row[3], price_per_person=row[4], image_url=row[5]))
            db.commit()
    finally:
        db.close()

@app.get("/")
def root():
    return {"message": "Travel Planning & Booking API is running", "docs": "/docs"}

@app.get("/api/destinations", response_model=list[schemas.DestinationOut])
def get_destinations(search: str = Query(default=""), category: str = Query(default=""), db: Session = Depends(get_db)):
    query = db.query(models.Destination)
    if search:
        term = f"%{search}%"
        query = query.filter(or_(models.Destination.name.ilike(term), models.Destination.country.ilike(term), models.Destination.description.ilike(term)))
    if category and category.lower() != "all":
        query = query.filter(models.Destination.category.ilike(category))
    return query.order_by(models.Destination.name).all()

@app.get("/api/destinations/{destination_id}", response_model=schemas.DestinationOut)
def get_destination(destination_id: int, db: Session = Depends(get_db)):
    item = db.get(models.Destination, destination_id)
    if not item:
        raise HTTPException(404, "Destination not found")
    return item

@app.post("/api/users", response_model=schemas.UserOut, status_code=201)
def create_user(payload: schemas.UserCreate, db: Session = Depends(get_db)):
    existing = db.query(models.User).filter(models.User.email == payload.email.lower()).first()
    if existing:
        return existing
    user = models.User(name=payload.name, email=payload.email.lower())
    db.add(user); db.commit(); db.refresh(user)
    return user

@app.get("/api/users", response_model=list[schemas.UserOut])
def get_users(db: Session = Depends(get_db)):
    return db.query(models.User).all()

@app.post("/api/trips", response_model=schemas.TripOut, status_code=201)
def create_trip(payload: schemas.TripCreate, db: Session = Depends(get_db)):
    if payload.end_date < payload.start_date:
        raise HTTPException(400, "End date must be on or after start date")
    if not db.get(models.User, payload.user_id):
        raise HTTPException(404, "User not found")
    if not db.get(models.Destination, payload.destination_id):
        raise HTTPException(404, "Destination not found")
    trip = models.Trip(**payload.model_dump())
    db.add(trip); db.commit(); db.refresh(trip)
    return trip

@app.get("/api/trips", response_model=list[schemas.TripOut])
def get_trips(db: Session = Depends(get_db)):
    return db.query(models.Trip).order_by(models.Trip.created_at.desc()).all()

@app.post("/api/bookings", response_model=schemas.BookingOut, status_code=201)
def create_booking(payload: schemas.BookingCreate, db: Session = Depends(get_db)):
    trip = db.query(models.Trip).options(joinedload(models.Trip.destination)).filter(models.Trip.id == payload.trip_id).first()
    if not trip:
        raise HTTPException(404, "Trip not found")
    nights = max((trip.end_date - trip.start_date).days, 1)
    total = trip.destination.price_per_person * trip.travellers
    booking = models.Booking(trip_id=trip.id, total_amount=round(total, 2), status="Confirmed")
    db.add(booking); db.commit(); db.refresh(booking)
    return booking

@app.get("/api/bookings")
def get_bookings(db: Session = Depends(get_db)):
    rows = db.query(models.Booking).options(joinedload(models.Booking.trip).joinedload(models.Trip.destination),
        joinedload(models.Booking.trip).joinedload(models.Trip.user)).order_by(models.Booking.booked_at.desc()).all()
    return [{
        "id": b.id, "trip_id": b.trip_id, "total_amount": b.total_amount, "status": b.status,
        "booked_at": b.booked_at, "travellers": b.trip.travellers,
        "destination": b.trip.destination.name, "country": b.trip.destination.country,
        "customer": b.trip.user.name, "start_date": b.trip.start_date, "end_date": b.trip.end_date
    } for b in rows]

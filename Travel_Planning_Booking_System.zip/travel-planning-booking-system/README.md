# Travel Planning & Booking System

A full-stack student project built with **React + Vite**, **FastAPI**, and **SQLite**.

## Features
- Browse destination cards with images, descriptions, country, category and estimated price.
- Search destinations and filter by category.
- Create a trip by selecting a destination, dates, travellers and notes.
- Create bookings and view booking history.
- Backend REST APIs for destinations, users, trips and bookings.
- SQLite database is created automatically and seeded with sample destinations.

## Requirements
- Python 3.10+
- Node.js 18+ and npm

## Run on Windows (CMD)

### 1. Start the backend
Open CMD and run:

```bat
cd travel-planning-booking-system\backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Backend: http://127.0.0.1:8000  
API documentation: http://127.0.0.1:8000/docs

### 2. Start the frontend
Open a **second CMD window**:

```bat
cd travel-planning-booking-system\frontend
npm install
npm run dev
```

Open the URL printed by Vite (normally http://localhost:5173).

## API endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/destinations` | List/search/filter destinations |
| GET | `/api/destinations/{id}` | Destination details |
| POST | `/api/users` | Register a user |
| GET | `/api/users` | List users |
| POST | `/api/trips` | Create a trip |
| GET | `/api/trips` | List trips |
| POST | `/api/bookings` | Create a booking |
| GET | `/api/bookings` | List bookings |

Interactive API docs are available at `/docs`.

## Project structure

```text
travel-planning-booking-system/
├── backend/
│   ├── app/
│   │   ├── __init__.py
│   │   ├── database.py
│   │   ├── main.py
│   │   ├── models.py
│   │   └── schemas.py
│   └── requirements.txt
├── frontend/
│   ├── index.html
│   ├── package.json
│   └── src/
│       ├── App.jsx
│       ├── main.jsx
│       └── style.css
└── README.md
```

## Notes
- This is an academic/demo application. It does not process real payments.
- The sample images are loaded from Unsplash over the internet.
- SQLite data is stored in `backend/travel.db` and persists between runs.

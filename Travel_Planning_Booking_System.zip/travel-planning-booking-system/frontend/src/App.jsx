import React, { useEffect, useMemo, useState } from 'react';
import { Search, MapPin, CalendarDays, Users, ArrowRight, Compass, Menu, X, Plane, CheckCircle2, Luggage, Clock3 } from 'lucide-react';

const API = 'http://127.0.0.1:8000/api';
const money = n => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(n);

export default function App() {
  const [destinations, setDestinations] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [active, setActive] = useState('Explore');
  const [selected, setSelected] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [mobileMenu, setMobileMenu] = useState(false);
  const [form, setForm] = useState({name:'', email:'', start_date:'', end_date:'', travellers:2, notes:''});

  const loadDestinations = async () => {
    setLoading(true); setError('');
    try {
      const params = new URLSearchParams({search, category});
      const res = await fetch(`${API}/destinations?${params}`);
      if (!res.ok) throw new Error('Could not load destinations');
      setDestinations(await res.json());
    } catch (e) { setError('Unable to connect to the API. Start the backend server and refresh.'); }
    finally { setLoading(false); }
  };
  const loadBookings = async () => {
    try { const res = await fetch(`${API}/bookings`); if (res.ok) setBookings(await res.json()); } catch {}
  };
  useEffect(() => { const t=setTimeout(loadDestinations, 250); return () => clearTimeout(t); }, [search, category]);
  useEffect(() => { loadBookings(); }, []);

  const categories = ['All', ...new Set(destinations.map(d => d.category))];
  const featured = useMemo(() => destinations.slice(0, 4), [destinations]);
  const update = e => setForm({...form, [e.target.name]: e.target.value});

  async function bookTrip(e) {
    e.preventDefault(); setNotice('');
    if (!selected) return;
    if (!form.name.trim() || !form.email.trim() || !form.start_date || !form.end_date) {
      setNotice('Please complete your name, email and travel dates.'); return;
    }
    if (form.end_date < form.start_date) { setNotice('Return date must be after departure date.'); return; }
    try {
      let userRes = await fetch(`${API}/users`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({name:form.name, email:form.email})});
      if (!userRes.ok) throw new Error('Could not create user');
      const user = await userRes.json();
      const tripRes = await fetch(`${API}/trips`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({
        user_id:user.id, destination_id:selected.id, start_date:form.start_date, end_date:form.end_date,
        travellers:Number(form.travellers), notes:form.notes
      })});
      if (!tripRes.ok) throw new Error('Could not create trip');
      const trip = await tripRes.json();
      const bookingRes = await fetch(`${API}/bookings`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({trip_id:trip.id})});
      if (!bookingRes.ok) throw new Error('Could not confirm booking');
      setNotice('Your trip is confirmed! Booking details are saved.');
      setSelected(null); setActive('My bookings'); setForm({name:'',email:'',start_date:'',end_date:'',travellers:2,notes:''});
      await loadBookings();
    } catch { setNotice('Booking failed. Please check that the backend is running and try again.'); }
  }

  return <div className="app-shell">
    <header className="navbar">
      <a className="brand" href="#" onClick={()=>setActive('Explore')}><span className="brand-icon"><Compass size={21}/></span> roamly<span className="brand-dot">.</span></a>
      <nav className={mobileMenu?'nav-links open':'nav-links'}>
        {['Explore','My bookings'].map(item=><button key={item} className={active===item?'nav-link active':'nav-link'} onClick={()=>{setActive(item);setMobileMenu(false);}}>{item}</button>)}
      </nav>
      <div className="nav-right"><span className="secure-note"><span className="green-dot"/> Your next story starts here</span><button className="mobile-toggle" onClick={()=>setMobileMenu(!mobileMenu)}>{mobileMenu?<X/>:<Menu/>}</button></div>
    </header>

    {active==='Explore' ? <>
      <section className="hero">
        <div className="hero-copy">
          <div className="eyebrow"><span/> THE WORLD IS WAITING</div>
          <h1>Find your next<br/><em>somewhere.</em></h1>
          <p>Curated places. Thoughtful journeys. Unforgettable memories. Your next adventure is closer than you think.</p>
          <a href="#discover" className="hero-cta">Explore destinations <ArrowRight size={17}/></a>
          <div className="hero-stats"><div><strong>08</strong><span>Handpicked places</span></div><i/><div><strong>01</strong><span>Perfect journey</span></div><i/><div><strong>∞</strong><span>Memories to make</span></div></div>
        </div>
        <div className="hero-visual">
          <img src="https://images.unsplash.com/photo-1518548419970-58e3b4079ab2?w=1400" alt="Tropical island view"/>
          <div className="image-shade"/>
          <div className="floating-card"><span className="sun-icon">✦</span><div><b>Make room for wonder</b><small>Every journey tells a story</small></div></div>
          <div className="image-caption"><MapPin size={14}/> Somewhere beautiful, always</div>
        </div>
      </section>

      <main id="discover" className="content">
        <div className="section-heading"><div><div className="eyebrow dark">THE COLLECTION</div><h2>Places worth <em>going places for.</em></h2><p>Find the feeling you've been looking for.</p></div><span className="result-count">{destinations.length} destinations</span></div>
        <div className="filter-bar">
          <div className="search-box"><Search size={18}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search places, countries, experiences..."/></div>
          <div className="category-filters">{['All','Beach','Adventure','Culture','Romance','City'].map(c=><button key={c} onClick={()=>setCategory(c)} className={category===c?'filter-chip chosen':'filter-chip'}>{c}</button>)}</div>
        </div>
        {error && <div className="error-banner">{error}</div>}
        {loading ? <div className="loading">Finding beautiful places for you...</div> : <div className="destination-grid">
          {destinations.map((d,i)=><article className="destination-card" key={d.id}>
            <div className="card-image"><img src={d.image_url} alt={d.name} loading="lazy"/><span className="category-tag">{d.category}</span><span className="card-number">0{i+1}</span></div>
            <div className="card-body"><div className="location"><MapPin size={13}/>{d.country}</div><h3>{d.name}</h3><p>{d.description}</p><div className="card-bottom"><div><small>STARTING FROM</small><strong>{money(d.price_per_person)}<small> / person</small></strong></div><button className="round-arrow" aria-label={`Plan trip to ${d.name}`} onClick={()=>{setSelected(d);setNotice('');}}><ArrowRight size={18}/></button></div></div>
          </article>)}
        </div>}
        {!loading && !destinations.length && <div className="empty-state">No destinations match your search. Try another keyword or category.</div>}
        <section className="inspiration"><div><span className="eyebrow">A LITTLE INSPIRATION</span><h2>Don't just see the world.<br/><em>Feel it.</em></h2><p>Pick a place, choose your dates, and let the good days begin.</p></div><div className="inspiration-art"><img src="https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=1000" alt="Scenic mountain landscape"/></div></section>
      </main>
    </> : <main className="content bookings-page">
      <div className="section-heading"><div><div className="eyebrow dark">YOUR JOURNEY JOURNAL</div><h2>Trips you've <em>planned.</em></h2><p>All your confirmed adventures, in one place.</p></div><button className="back-explore" onClick={()=>setActive('Explore')}>Explore more <ArrowRight size={16}/></button></div>
      {bookings.length ? <div className="booking-list">{bookings.map(b=><article className="booking-row" key={b.id}><div className="booking-icon"><Plane/></div><div className="booking-main"><h3>{b.destination}, {b.country}</h3><p>{b.customer} · {b.travellers} traveller(s)</p><small><CalendarDays size={13}/> {b.start_date} — {b.end_date}</small></div><div className="booking-side"><span className="confirmed"><CheckCircle2 size={14}/> {b.status}</span><strong>{money(b.total_amount)}</strong><small>Booking #{String(b.id).padStart(5,'0')}</small></div></article>)}</div> : <div className="empty-bookings"><Luggage size={42}/><h3>Your next adventure is waiting.</h3><p>You haven't booked a trip yet. Explore destinations and start planning.</p><button className="primary-btn" onClick={()=>setActive('Explore')}>Discover destinations <ArrowRight size={16}/></button></div>}
    </main>}
    <footer><a className="brand footer-brand" href="#"><span className="brand-icon"><Compass size={18}/></span> roamly<span className="brand-dot">.</span></a><span>Made for the love of going places.</span><span>© 2026 Roamly Travel</span></footer>

    {selected && <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)setSelected(null);}}><div className="booking-modal">
      <button className="modal-close" onClick={()=>setSelected(null)}><X size={20}/></button>
      <div className="modal-photo"><img src={selected.image_url} alt={selected.name}/><span>{selected.category} · {selected.country}</span></div>
      <div className="modal-content"><div className="eyebrow dark">LET'S MAKE IT HAPPEN</div><h2>Plan your <em>{selected.name}</em> escape.</h2><p className="modal-description">{selected.description}</p><div className="price-line">From <strong>{money(selected.price_per_person)}</strong> <span>/ person</span></div>
        <form onSubmit={bookTrip}>
          <div className="form-grid"><label>Your name<input name="name" value={form.name} onChange={update} placeholder="Full name" required/></label><label>Email address<input type="email" name="email" value={form.email} onChange={update} placeholder="you@example.com" required/></label><label>Departure date<input type="date" name="start_date" min={new Date().toISOString().slice(0,10)} value={form.start_date} onChange={update} required/></label><label>Return date<input type="date" name="end_date" min={form.start_date||new Date().toISOString().slice(0,10)} value={form.end_date} onChange={update} required/></label><label>Travellers<select name="travellers" value={form.travellers} onChange={update}>{[1,2,3,4,5,6,7,8,9,10].map(n=><option key={n} value={n}>{n} {n===1?'traveller':'travellers'}</option>)}</select></label><label className="full-field">A note for your trip <textarea name="notes" value={form.notes} onChange={update} placeholder="Anything you'd like us to know?"/></label></div>
          {notice && <div className="notice">{notice}</div>}<button className="primary-btn submit-btn" type="submit">Confirm booking <ArrowRight size={17}/></button><small className="demo-note"><Clock3 size={12}/> Demo booking · No payment required</small>
        </form>
      </div>
    </div></div>}
  </div>;
}
